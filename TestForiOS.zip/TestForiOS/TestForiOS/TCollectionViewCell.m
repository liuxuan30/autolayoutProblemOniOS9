//
//  TCollectionViewCell.m
//  TestForiOS
//
//  Created by Xuan on 9/17/15.
//  Copyright © 2015 Wingzero. All rights reserved.
//

#import "TCollectionViewCell.h"

@implementation TCollectionViewCell

- (void)awakeFromNib {
    // Initialization code
}

@end

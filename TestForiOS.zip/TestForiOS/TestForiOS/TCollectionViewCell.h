//
//  TCollectionViewCell.h
//  TestForiOS
//
//  Created by Xuan on 9/17/15.
//  Copyright © 2015 Wingzero. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TCollectionViewCell : UICollectionViewCell
@property (strong, nonatomic) IBOutlet UILabel *topLabel;

@end
